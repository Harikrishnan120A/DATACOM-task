import { useState, useEffect } from 'react'
import MapComponent from './components/MapComponent'
import LocationForm from './components/LocationForm'
import WeatherWidget from './components/WeatherWidget'
import './App.css'

function App() {
  const [locations, setLocations] = useState([])
  const [selectedLocation, setSelectedLocation] = useState(null)
  const [mapCenter, setMapCenter] = useState([51.505, -0.09]) // London coordinates
  
  // Fixed: Added missing dependency 'locations' to useEffect with cleanup
  useEffect(() => {
    let isMounted = true
    
    console.log('Map center updated:', mapCenter)
    if (locations.length > 0 && isMounted) {
      // Fixed: Check if component is still mounted before state update
      setSelectedLocation(locations[0])
    }
    
    return () => {
      isMounted = false
    }
  }, [mapCenter, locations]) // Fixed: Added 'locations' dependency

  const handleAddLocation = (location) => {
    // Fixed: Check for duplicate locations before adding
    const isDuplicate = locations.some(loc => 
      loc.id === location.id || 
      (Math.abs(loc.lat - location.lat) < 0.0001 && Math.abs(loc.lng - location.lng) < 0.0001)
    )
    
    if (!isDuplicate) {
      setLocations([...locations, location])
      setMapCenter([location.lat, location.lng])
    } else {
      console.warn('Location already exists or is very close to an existing location')
    }
  }

  const handleLocationSelect = (location) => {
    setSelectedLocation(location)
    setMapCenter([location.lat, location.lng])
  }

  // Fixed: Properly clearing all state when locations are cleared
  const clearAllLocations = () => {
    setLocations([])
    setSelectedLocation(null) // Fixed: Clear selectedLocation to avoid null reference
  }

  return (
    <div className="app">
      <header className="app-header">
        <h1>React Leaflet Map with Bugs</h1>
        <p>A demonstration app for identifying and fixing common React/Mapping bugs</p>
      </header>
      
      <main className="app-main">
        <div className="controls-panel">
          <LocationForm onAddLocation={handleAddLocation} />
          
          <div className="location-list">
            <h3>Saved Locations ({locations.length})</h3>
            {locations.map((location) => (
              // Fixed: Using unique identifier as key instead of index
              <div 
                key={location.id || `${location.lat}-${location.lng}`} 
                className={`location-item ${selectedLocation?.id === location.id ? 'selected' : ''}`}
                onClick={() => handleLocationSelect(location)}
              >
                <strong>{location.name}</strong>
                <br />
                <small>{location.lat.toFixed(4)}, {location.lng.toFixed(4)}</small>
              </div>
            ))}
            
            {locations.length > 0 && (
              <button onClick={clearAllLocations} className="clear-btn">
                Clear All Locations
              </button>
            )}
          </div>
        </div>

        <div className="map-panel">
          <MapComponent 
            center={mapCenter}
            locations={locations}
            onLocationSelect={handleLocationSelect}
            selectedLocation={selectedLocation}
          />
        </div>

        <div className="info-panel">
          {selectedLocation && (
            <WeatherWidget location={selectedLocation} />
          )}
        </div>
      </main>
    </div>
  )
}

export default App
