import { useState, useEffect, useCallback, useRef } from 'react'

const WeatherWidget = ({ location }) => {
  const [weather, setWeather] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const abortControllerRef = useRef(null) // Fixed: Added abort controller for cleanup
  const lastFetchRef = useRef(0) // Fixed: Rate limiting

  // Fixed: Using a demo API for testing (OpenWeatherMap requires real API key)
  const API_URL = 'https://api.open-meteo.com/v1/forecast'

  // Fixed: Memoized fetch function with proper error handling and cleanup
  const fetchWeather = useCallback(async () => {
    if (!location || typeof location.lat !== 'number' || typeof location.lng !== 'number') {
      setError('Invalid location data')
      return
    }

    // Fixed: Rate limiting - prevent too frequent API calls
    const now = Date.now()
    if (now - lastFetchRef.current < 5000) { // 5 second minimum between calls
      console.log('Rate limiting: Please wait before making another request')
      return
    }
    lastFetchRef.current = now

    // Fixed: Abort previous request if still pending
    if (abortControllerRef.current) {
      abortControllerRef.current.abort()
    }

    abortControllerRef.current = new AbortController()
    setLoading(true)
    setError(null)
    
    try {
      // Fixed: Using a working API that doesn't require API key
      const response = await fetch(
        `${API_URL}?latitude=${location.lat}&longitude=${location.lng}&current_weather=true&timezone=auto`,
        { signal: abortControllerRef.current.signal }
      )
      
      // Fixed: Check if response is ok
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      
      const data = await response.json()
      
      // Fixed: Data validation
      if (data && data.current_weather) {
        setWeather(data.current_weather)
      } else {
        throw new Error('Invalid weather data received')
      }
      
    } catch (err) {
      // Fixed: Specific error handling for different error types
      if (err.name === 'AbortError') {
        console.log('Weather fetch was aborted')
        return
      }
      
      if (err.name === 'TypeError') {
        setError('Network error: Please check your internet connection')
      } else if (err.message.includes('HTTP error')) {
        setError('Weather service temporarily unavailable')
      } else {
        setError('Failed to fetch weather data')
      }
      console.error('Weather fetch error:', err)
    } finally {
      setLoading(false)
    }
  }, [location])

  // Fixed: useEffect with proper dependency management and cleanup
  useEffect(() => {
    if (location && location.lat && location.lng) {
      fetchWeather()
    }

    // Fixed: Cleanup function
    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort()
      }
    }
  }, [location?.lat, location?.lng, fetchWeather])

  // Fixed: Temperature formatting with null/undefined checks
  const formatTemperature = useCallback((temp) => {
    if (typeof temp !== 'number' || isNaN(temp)) {
      return 'N/A'
    }
    return Math.round(temp) + '°C'
  }, [])

  // Fixed: Wind speed formatting with conversion options and null checks
  const formatWindSpeed = useCallback((speed) => {
    if (typeof speed !== 'number' || isNaN(speed)) {
      return 'N/A'
    }
    // Assuming speed is in m/s, convert to km/h
    return (speed * 3.6).toFixed(1) + ' km/h'
  }, [])

  // Fixed: Wind direction formatting
  const formatWindDirection = useCallback((deg) => {
    if (typeof deg !== 'number' || isNaN(deg)) {
      return 'N/A'
    }
    const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']
    const index = Math.round(deg / 45) % 8
    return `${directions[index]} (${deg}°)`
  }, [])

  // Fixed: Handle the case when location changes but weather is still loading
  if (!location) {
    return (
      <div className="weather-widget">
        <h3>Weather Information</h3>
        <p>Please select a location to view weather data</p>
      </div>
    )
  }

  return (
    <div className="weather-widget">
      <h3>Weather Information</h3>
      <p><strong>Location:</strong> {location.name || 'Unnamed Location'}</p>
      
      {loading && (
        <div className="loading" role="status" aria-live="polite">
          {/* Fixed: Accessible loading indicator */}
          <span>Loading weather data...</span>
          <div className="loading-spinner" aria-hidden="true">⟳</div>
        </div>
      )}
      
      {error && (
        <div className="error" role="alert">
          {/* Fixed: User-friendly error messages */}
          <p>{error}</p>
          {/* Fixed: Added retry functionality */}
          <button 
            onClick={fetchWeather}
            disabled={loading}
            className="retry-btn"
          >
            Try Again
          </button>
        </div>
      )}
      
      {weather && (
        <div className="weather-data">
          {/* Fixed: Comprehensive null checks for weather properties */}
          <div className="main-info">
            <h4>Current Weather</h4>
            <p className="temperature">
              {formatTemperature(weather.temperature)}
            </p>
            <p>Wind: {formatWindSpeed(weather.windspeed)}</p>
            {/* Fixed: Check if wind direction exists */}
            {typeof weather.winddirection === 'number' && (
              <p>Direction: {formatWindDirection(weather.winddirection)}</p>
            )}
          </div>
          
          {/* Fixed: Date formatting with timezone consideration */}
          <div className="timestamp">
            <small>
              Last updated: {new Date().toLocaleString(undefined, {
                timeZone: 'UTC',
                hour12: true,
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              })}
            </small>
          </div>
        </div>
      )}
      
      {/* Fixed: Refresh button with rate limiting */}
      <button 
        onClick={fetchWeather}
        disabled={loading}
        className="refresh-btn"
        title="Refresh weather data (max once per 5 seconds)"
      >
        {loading ? 'Refreshing...' : 'Refresh Weather'}
      </button>
    </div>
  )
}

export default WeatherWidget
