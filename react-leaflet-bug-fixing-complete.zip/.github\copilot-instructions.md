# Copilot Instructions

<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

## Project Overview
This is a React application with mapping functionality using Leaflet. The project is designed for demonstrating bug identification and fixing scenarios in a JavaScript/React environment.

## Key Technologies
- React 18+ with Vite
- Leaflet for interactive maps
- React-Leaflet for React integration
- JavaScript (ES6+)

## Development Guidelines
- Use functional components with React hooks
- Follow React best practices for state management
- Implement proper error boundaries for map components
- Use modern JavaScript features (async/await, destructuring, etc.)
- Focus on debugging common React and mapping library issues

## Common Bug Categories to Address
1. **State Management Issues**: Incorrect useState/useEffect usage
2. **Map Rendering Problems**: Leaflet initialization and cleanup
3. **Event Handling Bugs**: Click events, form submissions
4. **Memory Leaks**: Improper cleanup of map instances
5. **CSS/Styling Issues**: Map container sizing problems
6. **API Integration Bugs**: Async data fetching errors

## Testing and Debugging
- Use browser developer tools for debugging
- Implement console logging for tracking state changes
- Check for React warnings in development mode
- Monitor network requests for API calls
