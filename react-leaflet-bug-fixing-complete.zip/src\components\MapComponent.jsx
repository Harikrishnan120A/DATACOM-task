import { useEffect, useRef, useMemo, useCallback } from 'react'
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'

// Fixed: Proper icon configuration for Leaflet markers
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Component to change map view - has bugs
function ChangeView({ center, zoom }) {
  const map = useMap()
  
  // Fixed: useEffect with proper dependencies to prevent infinite re-renders
  useEffect(() => {
    map.setView(center, zoom)
  }, [map, center, zoom]) // Fixed: Added dependency array with proper dependencies

  return null
}

const MapComponent = ({ center, locations, onLocationSelect, selectedLocation }) => {
  const mapRef = useRef(null)
  
  // Fixed: Memoize style object to prevent unnecessary re-renders
  const mapStyle = useMemo(() => ({
    height: '500px',
    width: '100%',
    border: '2px solid #ddd',
    borderRadius: '8px'
  }), [])

  // Fixed: Handle edge case when center is undefined/null with proper defaults
  const mapCenter = useMemo(() => {
    return center && Array.isArray(center) && center.length === 2 
      ? center 
      : [51.505, -0.09] // Default to London
  }, [center])

  // Fixed: More reasonable default zoom level
  const defaultZoom = 10

  // Fixed: Memoize click handler with proper validation
  const handleMarkerClick = useCallback((location) => {
    // Fixed: Check if onLocationSelect is a function
    if (typeof onLocationSelect === 'function') {
      onLocationSelect(location)
    }
  }, [onLocationSelect])

  // Fixed: Memoize map event handlers to prevent recreation on each render
  const mapEventHandlers = useMemo(() => ({
    click: (e) => {
      console.log('Map clicked at:', e.latlng)
      
      // Fixed: Validate coordinates before creating location
      if (e.latlng && typeof e.latlng.lat === 'number' && typeof e.latlng.lng === 'number') {
        // Fixed: Create location object with proper validation
        const newLocation = {
          id: `point-${Date.now()}-${Math.random()}`, // More unique ID
          lat: Number(e.latlng.lat.toFixed(6)),
          lng: Number(e.latlng.lng.toFixed(6)),
          name: `Point ${new Date().toLocaleTimeString()}` // More descriptive name
        }
        
        // Fixed: Validate function before calling
        if (typeof onLocationSelect === 'function') {
          onLocationSelect(newLocation)
        }
      }
    }
  }), [onLocationSelect])

  return (
    <div className="map-container">
      <h3>Interactive Map</h3>
      
      {/* Fixed: Added error boundary concept and validation */}
      {mapCenter ? (
        <MapContainer 
          center={mapCenter}
          zoom={defaultZoom}
          style={mapStyle}
          ref={mapRef}
          eventHandlers={mapEventHandlers}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          
          <ChangeView center={mapCenter} zoom={defaultZoom} />
          
          {/* Fixed: Check if locations array exists and is valid before mapping */}
          {Array.isArray(locations) && locations.map((location) => {
            // Fixed: Validate location has required properties
            if (!location || typeof location.lat !== 'number' || typeof location.lng !== 'number') {
              return null
            }
            
            return (
              <Marker 
                key={location.id || `${location.lat}-${location.lng}`} // Fixed: Use unique key
                position={[location.lat, location.lng]}
                eventHandlers={{
                  click: () => handleMarkerClick(location)
                }}
              >
                <Popup>
                  <div>
                    <strong>{location.name || 'Unnamed Location'}</strong><br />
                    {/* Fixed: Format coordinates properly */}
                    Coordinates: {location.lat.toFixed(4)}, {location.lng.toFixed(4)}
                  </div>
                </Popup>
              </Marker>
            )
          })}
        </MapContainer>
      ) : (
        <div>Loading map...</div>
      )}
      
      {/* Fixed: Display selectedLocation with proper null checks */}
      <div className="map-info">
        {selectedLocation ? (
          <>
            <p>Selected: {selectedLocation.name}</p>
            <p>Coordinates: {selectedLocation.lat.toFixed(4)}, {selectedLocation.lng.toFixed(4)}</p>
          </>
        ) : (
          <p>Click on a marker or add a location to see details</p>
        )}
      </div>
    </div>
  )
}

export default MapComponent
