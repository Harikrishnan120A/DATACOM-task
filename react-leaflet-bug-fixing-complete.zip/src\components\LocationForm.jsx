import { useState, useCallback } from 'react'

const LocationForm = ({ onAddLocation }) => {
  const [formData, setFormData] = useState({
    name: '',
    lat: '',
    lng: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [errors, setErrors] = useState({}) // Fixed: Added error state

  // Fixed: Input validation function
  const validateForm = useCallback(() => {
    const newErrors = {}
    
    if (!formData.name.trim()) {
      newErrors.name = 'Location name is required'
    }
    
    const lat = parseFloat(formData.lat)
    if (isNaN(lat) || lat < -90 || lat > 90) {
      newErrors.lat = 'Latitude must be a number between -90 and 90'
    }
    
    const lng = parseFloat(formData.lng)
    if (isNaN(lng) || lng < -180 || lng > 180) {
      newErrors.lng = 'Longitude must be a number between -180 and 180'
    }
    
    return newErrors
  }, [formData])

  // Fixed: Proper form submission with validation and error handling
  const handleSubmit = async (e) => {
    e.preventDefault()
    
    // Fixed: Validate inputs before submission
    const validationErrors = validateForm()
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors)
      return
    }
    
    // Fixed: Check if onAddLocation is a function
    if (typeof onAddLocation !== 'function') {
      console.error('onAddLocation is not a function')
      return
    }
    
    setIsSubmitting(true)
    setErrors({}) // Clear previous errors
    
    try {
      // Fixed: Proper error handling for parseFloat
      const lat = parseFloat(formData.lat)
      const lng = parseFloat(formData.lng)
      
      const location = {
        id: `location-${Date.now()}-${Math.random()}`, // Fixed: More unique ID generation
        name: formData.name.trim(), // Fixed: Sanitize input by trimming
        lat: Number(lat.toFixed(6)), // Fixed: Limit precision
        lng: Number(lng.toFixed(6))
      }
      
      // Fixed: Proper async operation with error handling
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      onAddLocation(location)
      
      // Fixed: Clear form after successful submission
      setFormData({
        name: '',
        lat: '',
        lng: ''
      })
      
    } catch (error) {
      console.error('Error adding location:', error)
      setErrors({ submit: 'Failed to add location. Please try again.' })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    
    // Fixed: Basic input sanitization
    const sanitizedValue = value.replace(/[<>]/g, '') // Remove basic XSS characters
    
    setFormData(prev => ({
      ...prev,
      [name]: sanitizedValue
    }))
    
    // Clear error for this field when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }))
    }
  }

  // Fixed: Check if form is valid for button state
  const isFormValid = useCallback(() => {
    return formData.name.trim() && 
           formData.lat.trim() && 
           formData.lng.trim() &&
           Object.keys(validateForm()).length === 0
  }, [formData, validateForm])

  // Fixed: Loading state UI feedback and accessibility attributes
  return (
    <div className="location-form">
      <h3>Add New Location</h3>
      
      {errors.submit && (
        <div className="error" role="alert">
          {errors.submit}
        </div>
      )}
      
      <form onSubmit={handleSubmit} noValidate>
        <div className="form-group">
          <label htmlFor="location-name">Location Name:</label>
          <input
            id="location-name"
            type="text"
            name="name"
            value={formData.name}
            onChange={handleInputChange}
            placeholder="Enter location name"
            required // Fixed: Added required attribute
            aria-describedby={errors.name ? "name-error" : undefined}
            aria-invalid={!!errors.name}
          />
          {errors.name && (
            <div id="name-error" className="error-message" role="alert">
              {errors.name}
            </div>
          )}
        </div>
        
        <div className="form-group">
          <label htmlFor="location-lat">Latitude:</label>
          <input
            id="location-lat"
            type="number" // Fixed: Changed to number type for better UX
            step="any"
            min="-90" // Fixed: Added min/max validation for lat range
            max="90"
            name="lat"
            value={formData.lat}
            onChange={handleInputChange}
            placeholder="e.g., 51.505"
            required
            aria-describedby={errors.lat ? "lat-error" : undefined}
            aria-invalid={!!errors.lat}
          />
          {errors.lat && (
            <div id="lat-error" className="error-message" role="alert">
              {errors.lat}
            </div>
          )}
        </div>
        
        <div className="form-group">
          <label htmlFor="location-lng">Longitude:</label>
          <input
            id="location-lng"
            type="number" // Fixed: Changed to number type
            step="any"
            min="-180" // Fixed: Added min/max validation for lng range
            max="180"
            name="lng" 
            value={formData.lng}
            onChange={handleInputChange}
            placeholder="e.g., -0.09"
            required
            aria-describedby={errors.lng ? "lng-error" : undefined}
            aria-invalid={!!errors.lng}
          />
          {errors.lng && (
            <div id="lng-error" className="error-message" role="alert">
              {errors.lng}
            </div>
          )}
        </div>
        
        <button 
          type="submit"
          disabled={isSubmitting || !isFormValid()} // Fixed: Button disabled when form is invalid
          aria-describedby="submit-status"
        >
          {isSubmitting ? 'Adding...' : 'Add Location'}
        </button>
        
        {isSubmitting && (
          <div id="submit-status" className="loading" role="status" aria-live="polite">
            Adding location...
          </div>
        )}
      </form>
      
      <div className="quick-locations">
        <h4>Quick Add:</h4>
        {/* Fixed: Added error handling and unique IDs */}
        <button 
          type="button"
          onClick={() => {
            if (typeof onAddLocation === 'function') {
              onAddLocation({
                id: 'london-001',
                name: 'London',
                lat: 51.505,
                lng: -0.09
              })
            }
          }}
        >
          Add London
        </button>
        
        <button 
          type="button"
          onClick={() => {
            if (typeof onAddLocation === 'function') {
              onAddLocation({
                id: 'paris-001',
                name: 'Paris',
                lat: 48.8566,
                lng: 2.3522
              })
            }
          }}
        >
          Add Paris
        </button>
        
        {/* Fixed: Unique ID for New York */}
        <button 
          type="button"
          onClick={() => {
            if (typeof onAddLocation === 'function') {
              onAddLocation({
                id: 'newyork-001', // Fixed: Unique ID
                name: 'New York',
                lat: 40.7128,
                lng: -74.0060
              })
            }
          }}
        >
          Add New York
        </button>
      </div>
    </div>
  )
}

export default LocationForm
